# from django.urls import path
# from .views import GenericTreeViewSet
#
# urlpatterns = [
#     path('trees/<str:model_type>/', GenericTreeViewSet.as_view({...}), name='tree-list'),
# ]
